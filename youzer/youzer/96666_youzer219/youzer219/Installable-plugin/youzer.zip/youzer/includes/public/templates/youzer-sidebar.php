<?php
echo 'hamdolah';